package com.example.service;

public interface TransferService {

	boolean transfer(double amount, String fromAccNum, String toAccNum);

}