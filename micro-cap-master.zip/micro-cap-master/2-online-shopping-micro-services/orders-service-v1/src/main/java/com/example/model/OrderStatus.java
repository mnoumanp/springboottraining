package com.example.model;

public enum OrderStatus {

	ACTIVE,COMPLETED
	
}
